package ru.maxim.coinclicker;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  web = new WebView(this);
  web.setBackgroundColor(0xff101827);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowContentAccess(false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return true; }
  });
  web.setOnApplyWindowInsetsListener((v,insets)->{
   v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
   return insets;
  });
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onPause(){ super.onPause(); web.onPause(); web.pauseTimers(); }
 @Override protected void onResume(){ super.onResume(); if(web!=null){web.onResume();web.resumeTimers();} }
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
